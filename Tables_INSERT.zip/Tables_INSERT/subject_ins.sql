INSERT INTO subject (subject_id,subject_title) VALUES
	 (1,'English'),
	 (2,'Mathematics'),
	 (3,'Physics'),
	 (4,'Chemistry'),
	 (5,'Chess'),
	 (6,'Russian'),
	 (7,'Literature'),
	 (8,'History'),
	 (9,'Biology'),
	 (10,'Information Technology');
INSERT INTO subject (subject_id,subject_title) VALUES
	 (11,'German'),
	 (12,'French'),
	 (13,'Spanish'),
	 (14,'Economics'),
	 (15,'Geography'),
	 (16,'Chinese');
